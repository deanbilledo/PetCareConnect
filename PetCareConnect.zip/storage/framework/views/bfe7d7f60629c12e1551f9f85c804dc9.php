<?php
use Illuminate\Support\Str;


?>



<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <!-- Back Button -->
    <?php if(session('shop_mode')): ?>
        <a href="<?php echo e(route('shop.appointments')); ?>" class="inline-flex items-center text-gray-600 hover:text-gray-800 mb-6 mt-10">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
            </svg>
            Back to Appointments
        </a>
    <?php else: ?>
        <a href="<?php echo e(route('profile.pets.index')); ?>" class="inline-flex items-center text-gray-600 hover:text-gray-800 mb-6 mt-10">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
            </svg>
            Back to My Pets
        </a>
    <?php endif; ?>

    <!-- Pet Info Header -->
    <div class="bg-white rounded-lg shadow-md p-6 mb-8">
        <div class="flex items-center">
            <img src="<?php echo e($pet->profile_photo_url); ?>" alt="<?php echo e($pet->name); ?>" class="w-20 h-20 rounded-full object-cover mr-6">
            <div>
                <h1 class="text-3xl font-bold mb-2"><?php echo e($pet->name); ?>'s Health Record</h1>
                <div class="flex items-center">
                    <?php if($pet->isDeceased()): ?>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gray-100 text-gray-800 mr-3">
                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 12h.01M12 12h.01M19 12h.01M6 12a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0zm7 0a1 1 0 11-2 0 1 1 0 012 0z"/>
                            </svg>
                            Deceased
                        </span>
                        <span class="text-sm text-gray-600">
                            Passed away on <?php echo e($pet->death_date->format('M d, Y')); ?>

                            <?php if($pet->death_reason): ?>
                                • <?php echo e($pet->death_reason); ?>

                            <?php endif; ?>
                        </span>
                        <button onclick="openDeceasedModal()" class="ml-3 text-sm text-blue-600 hover:text-blue-800">
                            Edit Details
                        </button>
                    <?php else: ?>
                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 text-green-800">
                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                            </svg>
                            Active
                        </span>
                        <button onclick="openDeceasedModal()" class="ml-3 text-sm text-gray-600 hover:text-gray-800">
                            Mark as Deceased
                        </button>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(!$pet->isDeceased()): ?>
            <div class="ml-auto">
                <?php if(session('shop_mode')): ?>
                <button onclick="window.location.href='<?php echo e(route('profile.pets.add-health-record', $pet)); ?>'" 
                        class="bg-teal-500 text-white px-4 py-2 rounded-md hover:bg-teal-600 flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                    </svg>
                    Add Health Record
                </button>
                <?php else: ?>
                <button onclick="window.location.href='<?php echo e(route('profile.pets.user-add-health-record', $pet)); ?>'" 
                        class="bg-teal-500 text-white px-4 py-2 rounded-md hover:bg-teal-600 flex items-center">
                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                    </svg>
                    Add Health Record
                </button>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Deceased Status Modal -->
    <div id="deceased-modal" class="fixed inset-0 bg-gray-500 bg-opacity-75 hidden" x-data>
        <div class="flex items-center justify-center min-h-screen px-4">
            <div class="bg-white rounded-lg shadow-xl max-w-md w-full">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-4">
                        <?php echo e($pet->isDeceased() ? 'Update Deceased Details' : 'Mark as Deceased'); ?>

                    </h3>
                    <form action="<?php echo e(route('profile.pets.mark-deceased', $pet)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="space-y-4">
                            <div>
                                <label for="death_date" class="block text-sm font-medium text-gray-700">Date of Death</label>
                                <input type="date" id="death_date" name="death_date" required
                                       max="<?php echo e(date('Y-m-d')); ?>"
                                       value="<?php echo e($pet->death_date?->format('Y-m-d')); ?>"
                                       class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500">
                            </div>
                            <div>
                                <label for="death_reason" class="block text-sm font-medium text-gray-700">Reason (Optional)</label>
                                <textarea id="death_reason" name="death_reason" rows="3"
                                          class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500"><?php echo e($pet->death_reason); ?></textarea>
                            </div>
                        </div>
                        <div class="mt-6 flex justify-end space-x-3">
                            <button type="button" onclick="closeDeceasedModal()"
                                    class="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50">
                                Cancel
                            </button>
                            <button type="submit"
                                    class="px-4 py-2 bg-teal-500 text-white rounded-md text-sm font-medium hover:bg-teal-600">
                                <?php echo e($pet->isDeceased() ? 'Update Details' : 'Mark as Deceased'); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php if($pet->isDeceased()): ?>
        <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-8">
            <p class="text-gray-600 text-sm">
                This is a historical health record. No new health records can be added as this pet is deceased.
            </p>
        </div>
    <?php endif; ?>

    <!-- Health Records Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Vaccination Records -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-semibold">Vaccination History</h2>
                <?php if($pet->vaccinations->isNotEmpty()): ?>
                    <span class="text-sm text-gray-500">
                        Last Updated: <?php echo e($pet->vaccinations->first()->administered_date->format('M d, Y')); ?>

                    </span>
                <?php endif; ?>
            </div>
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $pet->vaccinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vaccination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="border-b pb-4">
                    <div class="flex justify-between mb-2">
                            <span class="font-medium"><?php echo e($vaccination->vaccine_name); ?></span>
                            <span class="text-sm <?php echo e($vaccination->next_due_date->isPast() ? 'text-red-600' : 'text-green-600'); ?>">
                                <?php echo e($vaccination->next_due_date->isPast() ? 'Overdue' : 'Up to date'); ?>

                            </span>
                    </div>
                    <div class="text-sm text-gray-600">
                            <p>Administered: <?php echo e($vaccination->administered_date->format('M d, Y')); ?></p>
                            <p>Next Due: <?php echo e($vaccination->next_due_date->format('M d, Y')); ?></p>
                            <p>Administered By: <?php echo e($vaccination->administered_by); ?></p>
                </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500 text-center py-4">No vaccination records found</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Health Issues -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold mb-4">Health Issues</h2>
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $pet->healthIssues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $issue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="border-b pb-4">
                    <div class="flex justify-between mb-2">
                        <div class="flex items-center">
                            <span class="font-medium"><?php echo e($issue->issue_title); ?></span>
                            <span class="ml-2 px-2 py-1 text-xs rounded-full <?php echo e($issue->is_resolved ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                <?php echo e($issue->is_resolved ? 'Resolved' : 'Active'); ?>

                            </span>
                        </div>
                        <div class="flex items-center space-x-4">
                            <span class="text-gray-500 text-sm"><?php echo e($issue->identified_date->format('M d, Y')); ?></span>
                            <?php if(!$pet->isDeceased()): ?>
                            <form action="<?php echo e(route('profile.pets.update-health-issue', ['pet' => $pet->id, 'issue' => $issue->id])); ?>" 
                                  method="POST" 
                                  class="inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <button type="submit" 
                                        class="text-sm <?php echo e($issue->is_resolved ? 'text-yellow-600 hover:text-yellow-700' : 'text-green-600 hover:text-green-700'); ?>">
                                    <?php echo e($issue->is_resolved ? 'Mark as Active' : 'Mark as Resolved'); ?>

                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                    <p class="text-sm text-gray-600 mb-2"><?php echo e($issue->description); ?></p>
                    <div class="text-sm text-gray-600">
                        <p>Treatment: <?php echo e($issue->treatment); ?></p>
                        <?php if($issue->vet_notes): ?>
                            <p class="mt-1">Vet Notes: <?php echo e($issue->vet_notes); ?></p>
                        <?php endif; ?>
                        <?php if($issue->resolved_date): ?>
                            <p class="mt-1 text-green-600">Resolved on: <?php echo e(\Carbon\Carbon::parse($issue->resolved_date)->format('M d, Y')); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500 text-center py-4">No health issues recorded</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Parasite Prevention -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold mb-4">Parasite Prevention</h2>
            <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $pet->parasiteControls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $control): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="border-b pb-4">
                    <div class="flex justify-between mb-2">
                            <span class="font-medium"><?php echo e($control->treatment_name); ?></span>
                            <span class="text-sm <?php echo e($control->next_treatment_date->isPast() ? 'text-red-600' : 'text-green-600'); ?>">
                                <?php echo e($control->next_treatment_date->isPast() ? 'Overdue' : 'Active'); ?>

                            </span>
                    </div>
                    <div class="text-sm text-gray-600">
                            <p>Last Applied: <?php echo e($control->treatment_date->format('M d, Y')); ?></p>
                            <p>Next Due: <?php echo e($control->next_treatment_date->format('M d, Y')); ?></p>
                            <p>Type: <?php echo e($control->treatment_type); ?> Treatment</p>
                </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500 text-center py-4">No parasite control records found</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h2 class="text-xl font-semibold mb-4">Health Summary</h2>
            <div class="grid grid-cols-2 gap-4">
                <div class="border rounded-lg p-4">
                    <p class="text-sm text-gray-600">Total Vaccinations</p>
                    <p class="text-2xl font-semibold"><?php echo e($pet->vaccinations->count()); ?></p>
                    </div>
                <div class="border rounded-lg p-4">
                    <p class="text-sm text-gray-600">Active Health Issues</p>
                    <p class="text-2xl font-semibold"><?php echo e($pet->healthIssues->where('is_resolved', false)->count()); ?></p>
                    </div>
                <div class="border rounded-lg p-4">
                    <p class="text-sm text-gray-600">Upcoming Due Dates</p>
                    <p class="text-2xl font-semibold">
                        <?php echo e($pet->vaccinations->concat($pet->parasiteControls)
                            ->filter(function($record) {
                                return $record->next_due_date && 
                                       $record->next_due_date->isFuture() && 
                                       $record->next_due_date->diffInDays(now()) <= 30;
                            })->count()); ?>

                    </p>
                </div>
                <div class="border rounded-lg p-4">
                    <p class="text-sm text-gray-600">Overdue Items</p>
                    <p class="text-2xl font-semibold text-red-600">
                        <?php echo e($pet->vaccinations->concat($pet->parasiteControls)
                            ->filter(function($record) {
                                return $record->next_due_date && 
                                       $record->next_due_date->isPast();
                            })->count()); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    function openDeceasedModal() {
        document.getElementById('deceased-modal').classList.remove('hidden');
    }

    function closeDeceasedModal() {
        document.getElementById('deceased-modal').classList.add('hidden');
    }

    // Close modal when clicking outside
    document.getElementById('deceased-modal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeDeceasedModal();
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make(session('shop_mode') ? 'layouts.shop' : 'layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\New folder\htdocs\PetCareConnect\resources\views\profile\pets\health-record.blade.php ENDPATH**/ ?>