<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title><?php echo e(config('app.name', 'Pet Care Connect')); ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">
    
    <!-- Styles -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- OpenStreetMap CSS and JS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
    
    <!-- Additional Styles -->
    <?php echo $__env->yieldPushContent('styles'); ?>

    <!-- Custom Styles -->
    <style>
        [x-cloak] { 
            display: none !important; 
        }
    </style>
</head>
<body class="bg-gray-100 font-[Poppins]">
    <!-- Content -->
    <?php echo $__env->yieldContent('content'); ?>

    <!-- Scripts -->
    <?php echo $__env->yieldPushContent('scripts'); ?>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            console.log('Leaflet loaded:', typeof L !== 'undefined');
        });
    </script>
</body>
</html> <?php /**PATH C:\New folder\htdocs\PetCareConnect\resources\views\layouts\auth.blade.php ENDPATH**/ ?>