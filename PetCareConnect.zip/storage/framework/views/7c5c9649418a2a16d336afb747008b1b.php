<?php $__env->startSection('content'); ?>
    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6">
                    <!-- Reviews Header -->
                    <div class="mb-8">
                        <h2 class="text-2xl font-bold text-gray-900">Shop Reviews</h2>
                        <p class="mt-1 text-sm text-gray-600">Manage and view all your customer reviews</p>
                    </div>

                    <!-- Reviews Stats -->
                    <?php
                        $shopRatings = $shop->ratings;
                        $avgRating = $shopRatings->avg('rating') ?? 0;
                        $totalReviews = $shopRatings->count();
                        $positiveReviews = $shopRatings->where('rating', '>=', 4)->count();
                        $positivePercentage = $totalReviews > 0 ? ($positiveReviews / $totalReviews * 100) : 0;
                        $newThisMonth = $shopRatings->where('created_at', '>=', now()->startOfMonth())->count();
                    ?>
                    
                    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                        <div class="bg-white p-6 rounded-lg border">
                            <div class="text-4xl font-bold text-blue-600"><?php echo e(number_format($avgRating, 1)); ?></div>
                            <div class="text-sm text-gray-600">Average Rating</div>
                        </div>
                        <div class="bg-white p-6 rounded-lg border">
                            <div class="text-4xl font-bold text-blue-600"><?php echo e($totalReviews); ?></div>
                            <div class="text-sm text-gray-600">Total Reviews</div>
                        </div>
                        <div class="bg-white p-6 rounded-lg border">
                            <div class="text-4xl font-bold text-green-600"><?php echo e(number_format($positivePercentage, 0)); ?>%</div>
                            <div class="text-sm text-gray-600">Positive Reviews</div>
                        </div>
                        <div class="bg-white p-6 rounded-lg border">
                            <div class="text-4xl font-bold text-yellow-600"><?php echo e($newThisMonth); ?></div>
                            <div class="text-sm text-gray-600">New This Month</div>
                        </div>
                    </div>

                    <!-- Rating Distribution -->
                    <div class="mb-8">
                        <h3 class="text-lg font-semibold mb-4">Rating Distribution</h3>
                        <div class="space-y-2">
                            <?php $__currentLoopData = range(5, 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $ratingCount = $shopRatings->where('rating', $rating)->count();
                                    $percentage = $totalReviews > 0 ? ($ratingCount / $totalReviews * 100) : 0;
                                ?>
                                <div class="flex items-center">
                                    <div class="w-16 text-sm text-gray-600"><?php echo e($rating); ?> stars</div>
                                    <div class="flex-1 h-4 mx-2 bg-gray-200 rounded-full overflow-hidden">
                                        <div class="h-full bg-yellow-400 rounded-full" style="width: <?php echo e($percentage); ?>%"></div>
                                    </div>
                                    <div class="w-16 text-sm text-gray-600"><?php echo e($ratingCount); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    <!-- Reviews List -->
                    <div class="space-y-6">
                        <h3 class="text-lg font-semibold">Recent Reviews</h3>
                        <?php $__empty_1 = true; $__currentLoopData = $ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="bg-white rounded-lg shadow p-6">
                                <!-- User Info and Rating -->
                                <div class="flex items-start justify-between mb-4">
                                    <div class="flex items-center">
                                        <img src="<?php echo e($rating->user->profile_photo_path ? asset('storage/' . $rating->user->profile_photo_path) : asset('images/default-profile.png')); ?>" 
                                             alt="Profile" 
                                             class="w-10 h-10 rounded-full object-cover mr-3">
                                        <div>
                                            <div class="font-medium"><?php echo e($rating->user->first_name); ?> <?php echo e($rating->user->last_name); ?></div>
                                            <div class="flex items-center">
                                                <div class="text-yellow-400">
                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <?php if($i <= $rating->rating): ?>
                                                            <span class="text-2xl">★</span>
                                                        <?php else: ?>
                                                            <span class="text-2xl text-gray-300">★</span>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </div>
                                                <span class="text-gray-500 text-sm ml-2"><?php echo e($rating->created_at->diffForHumans()); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Services -->
                                <?php if($rating->appointment && $rating->appointment->services->isNotEmpty()): ?>
                                    <div class="mb-4">
                                        <div class="flex flex-wrap gap-2">
                                            <?php $__currentLoopData = $rating->appointment->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full">
                                                    <?php echo e($service->name); ?>

                                                </span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <!-- Review Text -->
                                <?php if($rating->review): ?>
                                    <div class="mb-4">
                                        <p class="text-gray-700"><?php echo e($rating->review); ?></p>
                                    </div>
                                <?php endif; ?>

                                <!-- Employee Rating -->
                                <?php if($rating->appointment && $rating->appointment->employee && $rating->appointment->employee->staffRatings()->where('appointment_id', $rating->appointment_id)->exists()): ?>
                                    <?php
                                        $staffRating = $rating->appointment->employee->staffRatings()
                                            ->where('appointment_id', $rating->appointment_id)
                                            ->first();
                                    ?>
                                    <div class="mt-4 bg-gray-50 rounded-lg p-4">
                                        <div class="flex items-center mb-2">
                                            <img src="<?php echo e($rating->appointment->employee->profile_photo_url); ?>" 
                                                 alt="<?php echo e($rating->appointment->employee->name); ?>" 
                                                 class="w-8 h-8 rounded-full object-cover mr-2">
                                            <div>
                                                <p class="font-medium text-sm"><?php echo e($rating->appointment->employee->name); ?></p>
                                                <div class="flex items-center">
                                                    <div class="text-yellow-400">
                                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                                            <?php if($i <= $staffRating->rating): ?>
                                                                <span class="text-lg">★</span>
                                                            <?php else: ?>
                                                                <span class="text-lg text-gray-300">★</span>
                                                            <?php endif; ?>
                                                        <?php endfor; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php if($staffRating->review): ?>
                                            <p class="text-gray-700 text-sm mt-2"><?php echo e($staffRating->review); ?></p>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                                <!-- Shop Comment Section -->
                                <div class="mt-4 border-t pt-4">
                                    <?php if($rating->shop_comment): ?>
                                        <div class="bg-blue-50 rounded-lg p-4 mb-4">
                                            <p class="text-sm font-medium text-blue-800 mb-1">Shop's Response:</p>
                                            <p class="text-gray-700"><?php echo e($rating->shop_comment); ?></p>
                                        </div>
                                    <?php endif; ?>

                                    <form action="<?php echo e(route('shop.reviews.comment', $rating->id)); ?>" method="POST" class="mt-2">
                                        <?php echo csrf_field(); ?>
                                        <div class="flex gap-2">
                                            <input type="text" 
                                                   name="shop_comment" 
                                                   class="flex-1 rounded-lg border-gray-300 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50" 
                                                   placeholder="Add a response to this review..."
                                                   value="<?php echo e($rating->shop_comment); ?>">
                                            <button type="submit" 
                                                    class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                                                <?php echo e($rating->shop_comment ? 'Update Response' : 'Add Response'); ?>

                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-gray-500 text-center py-8">
                                No reviews yet.
                            </div>
                        <?php endif; ?>

                        <!-- Pagination -->
                        <div class="mt-6">
                            <?php echo e($ratings->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.shop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\New folder\htdocs\PetCareConnect\resources\views\shop\reviews\index.blade.php ENDPATH**/ ?>