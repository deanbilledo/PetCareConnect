<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title><?php echo e(config('app.name', 'Pet Care Connect')); ?></title>
    
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- jQuery and Leaflet are now imported via npm/Vite -->
            
    <style>
        [x-cloak] { 
            display: none !important; 
        }
    </style>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body class="bg-gray-100 font-[Poppins] min-h-screen min-h-screen flex flex-col">
    <!-- Global Loading Overlay (hidden by default) -->
    <div id="globalLoadingOverlay" class="hidden">
        <?php if (isset($component)) { $__componentOriginal50a73e7d57605f77e4f417026f0ee281 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal50a73e7d57605f77e4f417026f0ee281 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.loading-screen','data' => ['fullScreen' => 'true','message' => 'Hold Tight...','subMessage' => 'Catho is spinning up... Getting things ready for you!...','size' => 'lg','class' => 'backdrop-blur-sm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('loading-screen'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['fullScreen' => 'true','message' => 'Hold Tight...','subMessage' => 'Catho is spinning up... Getting things ready for you!...','size' => 'lg','class' => 'backdrop-blur-sm']); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal50a73e7d57605f77e4f417026f0ee281)): ?>
<?php $attributes = $__attributesOriginal50a73e7d57605f77e4f417026f0ee281; ?>
<?php unset($__attributesOriginal50a73e7d57605f77e4f417026f0ee281); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal50a73e7d57605f77e4f417026f0ee281)): ?>
<?php $component = $__componentOriginal50a73e7d57605f77e4f417026f0ee281; ?>
<?php unset($__componentOriginal50a73e7d57605f77e4f417026f0ee281); ?>
<?php endif; ?>
    </div>

    <?php
        $showSidebar = auth()->check() && 
                      auth()->user()->shop && 
                      session()->has('shop_mode') && 
                      session('shop_mode') === true &&
                      !request()->routeIs('home') &&
                      !request()->is('/');
    ?>

    <!-- Toast Notifications -->
    <div x-data="{ 
        toasts: [],
        toastCount: 0,
        add(toast) {
            const id = Date.now() + this.toastCount++;
            const newToast = {...toast, id };
            this.toasts.unshift(newToast);
            setTimeout(() => {
                this.remove(newToast.id);
            }, toast.timeout || 5000);
        },
        remove(id) {
            this.toasts = this.toasts.filter(toast => toast.id !== id);
        }
    }" 
    class="fixed top-4 right-4 z-50 space-y-4 w-80 mt-20"
    @toast.window="add($event.detail)">
        <template x-for="toast in toasts" :key="toast.id">
            <div 
                x-show="true"
                x-transition:enter="transition ease-out duration-300"
                x-transition:enter-start="opacity-0 transform translate-x-20"
                x-transition:enter-end="opacity-100 transform translate-x-0"
                x-transition:leave="transition ease-in duration-200"
                x-transition:leave-start="opacity-100 transform translate-x-0"
                x-transition:leave-end="opacity-0 transform translate-x-20"
                :class="{
                    'bg-green-100 border-green-400 text-green-700': toast.type === 'success',
                    'bg-red-100 border-red-400 text-red-700': toast.type === 'error',
                    'bg-blue-100 border-blue-400 text-blue-700': toast.type === 'info',
                    'bg-yellow-100 border-yellow-400 text-yellow-700': toast.type === 'warning'
                }"
                class="rounded-lg border-l-4 p-4 shadow-md flex justify-between items-start"
            >
                <div class="flex items-start">
                    <template x-if="toast.type === 'success'">
                        <svg class="h-5 w-5 mr-3 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                        </svg>
                    </template>
                    <template x-if="toast.type === 'error'">
                        <svg class="h-5 w-5 mr-3 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </template>
                    <template x-if="toast.type === 'info'">
                        <svg class="h-5 w-5 mr-3 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </template>
                    <template x-if="toast.type === 'warning'">
                        <svg class="h-5 w-5 mr-3 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
                        </svg>
                    </template>
                    <span x-text="toast.message"></span>
                </div>
                <button @click="remove(toast.id)" class="text-gray-400 hover:text-gray-600">
                    <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>
        </template>
    </div>

    <!-- Fixed Header -->
    <div class="fixed top-0 left-0 right-0 z-50 bg-white shadow-sm">
        <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- Main Content with Sidebar -->
    <div class="pt-16"> <!-- Add padding-top for fixed header -->
        <?php if($showSidebar): ?>
            <!-- Fixed Sidebar -->
            <div class="fixed left-0 top-16 bottom-0 w-56 bg-gray-50 shadow-md overflow-y-auto">
                <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- Main Content with margin for sidebar -->
            <div class="ml-56 ">
                <main class="p-6 ">
                    <?php echo $__env->yieldContent('content'); ?>
                </main> 
            </div>
        <?php else: ?>
            <!-- Main Content without sidebar -->
            <div>
                <main class="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>
            <!-- Only show footer in non-shop mode -->
            <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>

    <!-- Modal Component -->
    <div 
        x-data="{ show: false, title: '', content: '', onConfirm: null }"
        x-show="show"
        x-cloak
        @modal.window="
            show = true;
            title = $event.detail.title;
            content = $event.detail.content;
            onConfirm = $event.detail.onConfirm || function(){};
        "
        class="fixed inset-0 flex items-center justify-center z-50"
    >
        <div 
            x-show="show" 
            x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0"
            x-transition:enter-end="opacity-100"
            x-transition:leave="transition ease-in duration-200"
            x-transition:leave-start="opacity-100"
            x-transition:leave-end="opacity-0"
            class="fixed inset-0 bg-black bg-opacity-50"
            @click="show = false"
        ></div>
        
        <div 
            x-show="show" 
            x-transition:enter="transition ease-out duration-300"
            x-transition:enter-start="opacity-0 transform scale-95"
            x-transition:enter-end="opacity-100 transform scale-100"
            x-transition:leave="transition ease-in duration-200"
            x-transition:leave-start="opacity-100 transform scale-100"
            x-transition:leave-end="opacity-0 transform scale-95"
            class="bg-white rounded-lg shadow-xl max-w-md w-full z-10 relative"
            @click.away="show = false"
        >
            <div class="px-6 py-4 border-b">
                <h3 class="text-lg font-medium text-gray-900" x-text="title"></h3>
            </div>
            <div class="p-6">
                <p class="text-gray-700" x-html="content"></p>
            </div>
            <div class="px-6 py-4 bg-gray-50 flex justify-end space-x-3 rounded-b-lg">
                <button 
                    @click="show = false"
                    class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors"
                >
                    Cancel
                </button>
                <button 
                    @click="onConfirm(); show = false"
                    class="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition-colors"
                >
                    Confirm
                </button>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <!-- AlpineJS and app.js are now loaded via Vite -->
    <!-- Shop Search Script (for home page only) -->
    <?php if(Route::currentRouteName() == 'home'): ?>
    <script src="<?php echo e(asset('js/shop-search.js')); ?>" defer></script>
    <?php endif; ?>
    <script src="<?php echo e(asset('js/loading-screen.js')); ?>"></script>
    
    <!-- Initialize Session Messages as Toast Notifications -->
    <script>
        document.addEventListener('alpine:init', () => {
            <?php if(session('success')): ?>
                window.dispatchEvent(new CustomEvent('toast', {
                    detail: {
                        type: 'success',
                        message: '<?php echo e(session('success')); ?>'
                    }
                }));
            <?php endif; ?>
            
            <?php if(session('error')): ?>
                window.dispatchEvent(new CustomEvent('toast', {
                    detail: {
                        type: 'error',
                        message: '<?php echo e(session('error')); ?>'
                    }
                }));
            <?php endif; ?>
            
            <?php if(session('info')): ?>
                window.dispatchEvent(new CustomEvent('toast', {
                    detail: {
                        type: 'info',
                        message: '<?php echo e(session('info')); ?>'
                    }
                }));
            <?php endif; ?>
            
            <?php if(session('warning')): ?>
                window.dispatchEvent(new CustomEvent('toast', {
                    detail: {
                        type: 'warning',
                        message: '<?php echo e(session('warning')); ?>'
                    }
                }));
            <?php endif; ?>
        });
    </script>
    
    <?php echo $__env->yieldPushContent('scripts'); ?>

    <?php if(session()->has('mode_switch')): ?>
    <script>
        if (performance && performance.navigation.type === performance.navigation.TYPE_BACK_FORWARD) {
            location.reload(true);
        }
    </script>
    <?php endif; ?>
</body>
</html> <?php /**PATH C:\New folder\htdocs\PetCareConnect\resources\views\layouts\app.blade.php ENDPATH**/ ?>