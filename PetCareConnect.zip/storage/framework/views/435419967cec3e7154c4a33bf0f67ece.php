<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'fullScreen' => false,
    'message' => 'Loading...',
    'subMessage' => 'Please wait while we process your request',
    'size' => 'md' // sm, md, lg, xl, 2xl options for GIF size
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'fullScreen' => false,
    'message' => 'Loading...',
    'subMessage' => 'Please wait while we process your request',
    'size' => 'md' // sm, md, lg, xl, 2xl options for GIF size
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $containerClasses = $fullScreen 
        ? 'fixed inset-0 z-50 flex items-center justify-center bg-white bg-opacity-90' 
        : 'flex items-center justify-center p-6 rounded-lg';
    
    $sizeClasses = [
        'sm' => 'w-16 h-16',
        'md' => 'w-32 h-32',
        'lg' => 'w-48 h-48',
        'xl' => 'w-64 h-64',
        '2xl' => 'w-96 h-96',
    ][$size] ?? 'w-32 h-32';
?>

<div <?php echo e($attributes->merge(['class' => $containerClasses])); ?>>
    <div class="text-center">
        <div class="flex flex-col items-center justify-center">
            <img src="<?php echo e(asset('images/loadingscreen.gif')); ?>" alt="Loading" class="<?php echo e($sizeClasses); ?> mx-auto mb-4">
            <div class="bg-gray-50 px-8 py-4 rounded-lg shadow-inner w-full max-w-md mx-auto">
                <h3 class="text-lg font-medium text-gray-800 mb-2"><?php echo e($message); ?></h3>
                <p class="text-gray-600 text-sm sm:text-base mb-1"><?php echo e($subMessage); ?></p>
                
                <?php if($slot->isNotEmpty()): ?>
                    <div class="mt-3">
                        <?php echo e($slot); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div> <?php /**PATH C:\New folder\htdocs\PetCareConnect\resources\views\components\loading-screen.blade.php ENDPATH**/ ?>