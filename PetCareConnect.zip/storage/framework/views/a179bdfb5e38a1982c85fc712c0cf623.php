<?php $__env->startComponent('mail::message'); ?>

<div style="text-align: center; margin-bottom: 30px;">
    <img src="<?php echo e(url('images/logo.png')); ?>" alt="<?php echo e(config('app.name')); ?>" style="max-width: 200px; height: auto;">
</div>


<?php if(! empty($greeting)): ?>
# <?php echo e($greeting); ?>

<?php else: ?>
# Hello!
<?php endif; ?>


<div style="display: flex; justify-content: center; margin: 20px 0;">
    <div style="text-align: center; max-width: 600px;">
        <table cellpadding="0" cellspacing="0" border="0" width="100%">
            <tr>
                <td width="25%" style="padding: 5px;">
                    <img src="<?php echo e(url('images/dog1.png')); ?>" alt="Happy Pet" style="width: 100%; border-radius: 10px;">
                </td>
                <td width="25%" style="padding: 5px;">
                    <img src="<?php echo e(url('images/dog2.png')); ?>" alt="Happy Pet" style="width: 100%; border-radius: 10px;">
                </td>
                <td width="25%" style="padding: 5px;">
                    <img src="<?php echo e(url('images/dog3.png')); ?>" alt="Happy Pet" style="width: 100%; border-radius: 10px;">
                </td>
                <td width="25%" style="padding: 5px;">
                    <img src="<?php echo e(url('images/dog4.png')); ?>" alt="Happy Pet" style="width: 100%; border-radius: 10px;">
                </td>
            </tr>
        </table>
    </div>
</div>


<?php $__currentLoopData = $introLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($line); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php if(isset($actionText)): ?>
<?php
    $color = match ($level) {
        'success', 'error' => $level,
        default => 'primary',
    };
?>
<div style="text-align: center; margin: 35px 0;">
<?php $__env->startComponent('mail::button', ['url' => $actionUrl, 'color' => $color]); ?>
<?php echo e($actionText); ?>

<?php echo $__env->renderComponent(); ?>
</div>
<?php endif; ?>


<?php $__currentLoopData = $outroLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($line); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php if(! empty($salutation)): ?>
<?php echo e($salutation); ?>

<?php else: ?>
Best regards,<br>
<?php echo e(config('app.name')); ?> Team
<?php endif; ?>


<?php if(isset($actionText)): ?>
<?php $__env->slot('subcopy'); ?>
<?php echo app('translator')->get(
    "If you're having trouble clicking the \":actionText\" button, copy and paste the URL below\n".
    'into your web browser:',
    [
        'actionText' => $actionText,
    ]
); ?> <span class="break-all">[<?php echo e($displayableActionUrl); ?>](<?php echo e($actionUrl); ?>)</span>
<?php $__env->endSlot(); ?>
<?php endif; ?>


<div style="text-align: center; margin-top: 30px; color: #718096; font-size: 0.875rem;">
    <p>Connect with us</p>
    <div style="margin-top: 10px;">
        <a href="#" style="text-decoration: none; margin: 0 10px;"><img src="https://cdn-icons-png.flaticon.com/512/733/733547.png" width="24" height="24" alt="Facebook"></a>
        <a href="#" style="text-decoration: none; margin: 0 10px;"><img src="https://cdn-icons-png.flaticon.com/512/3670/3670151.png" width="24" height="24" alt="Instagram"></a>
        <a href="#" style="text-decoration: none; margin: 0 10px;"><img src="https://cdn-icons-png.flaticon.com/512/733/733579.png" width="24" height="24" alt="Twitter"></a>
    </div>
    <p style="margin-top: 15px;">&copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name')); ?>. All rights reserved.</p>
</div>
<?php echo $__env->renderComponent(); ?> <?php /**PATH C:\New folder\htdocs\PetCareConnect\resources\views\vendor\notifications\email.blade.php ENDPATH**/ ?>